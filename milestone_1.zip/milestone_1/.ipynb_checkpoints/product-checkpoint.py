class Product:
    def __init__(self, id, name, premium, status="active"):
        self.id = id
        self.name = name
        self.premium = premium
        self.status = status

    def update(self, name=None, premium=None):
        if name:
            self.name = name
        if premium:
            self.premium = premium
        return f"Product {self.name} updated."

    def suspend(self):
        if self.status == "active":
            self.status = "suspended"
            return f"Product {self.name} suspended."
        return f"Product {self.name} is already {self.status}."

    def remove(self):
        self.status = "removed"
        return f"Product {self.name} removed."
```